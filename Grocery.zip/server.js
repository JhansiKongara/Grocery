let express = require("express");
let path = require("path");
let bodyParser = require("body-parser");
require("./dbConnection/db");
require("dotenv").config();
let app = express();
app.use(bodyParser.json());
var cors = require("cors");
app.use(cors());
console.log(process.env.NODE_ENV);
let AuthRoute = require("./routers/authRouter");
const PORT = process.env.PORT || 4000;
app.use(express.static(path.join(__dirname, "grocery")));
app.use("/api", AuthRoute);
app.get("/*", (req, res) => {
  res.sendFile(path.join(__dirname + "/grocery/index.html"));
});
app.listen(PORT, () => {
  console.log("server Running on Port Number: " + PORT);
});
